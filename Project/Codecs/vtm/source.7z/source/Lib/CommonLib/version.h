#if ! defined( VTM_VERSION )
#define VTM_VERSION "19.2"
#endif
